﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace pr_21._102_VershininAI_1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string text = txt_Enter.Text;

            if (text.Length == 20)
            {
                bool flag = false;
                try
                {
                    double a = Convert.ToDouble(text);
                    flag = true;
                }
                catch
                {
                    MessageBox.Show("Неправильный ввод");
                    txt_Enter.Text = "";
                }

                if(flag)
                {
                    char[] txtInChar = text.ToCharArray();

                    double multi = Convert.ToDouble(txtInChar[0].ToString()) * Convert.ToDouble(txtInChar[1].ToString()) * Convert.ToDouble(txtInChar[2].ToString());
                    double summ = Convert.ToDouble(txtInChar[19].ToString()) + Convert.ToDouble(txtInChar[18].ToString()) + Convert.ToDouble(txtInChar[17].ToString()) + Convert.ToDouble(txtInChar[16].ToString()) + Convert.ToDouble(txtInChar[15].ToString()) + Convert.ToDouble(txtInChar[14].ToString()) + Convert.ToDouble(txtInChar[13].ToString()) + Convert.ToDouble(txtInChar[12].ToString()) + Convert.ToDouble(txtInChar[11].ToString()); 

                    if (multi==summ)
                    {
                        MessageBox.Show("Равны");
                    }
                    else
                    {
                        MessageBox.Show("Не равны");
                    }
                }
            }
            else
            {
                MessageBox.Show("Не 20");
            }
            
        }

        private void txt_Enter_TextChanged(object sender, TextChangedEventArgs e)
        {
            lb_Count.Content = txt_Enter.Text.Length;
        }
    }
}
