# Vershinin_AI_RK_VAR1
